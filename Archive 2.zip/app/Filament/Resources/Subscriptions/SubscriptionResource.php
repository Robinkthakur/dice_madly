<?php

namespace App\Filament\Resources\Subscriptions;

use App\Filament\Resources\Subscriptions\Pages\CreateSubscription;
use App\Filament\Resources\Subscriptions\Pages\EditSubscription;
use App\Filament\Resources\Subscriptions\Pages\ListSubscriptions;
use App\Filament\Resources\Subscriptions\Schemas\SubscriptionForm;
use App\Filament\Resources\Subscriptions\Tables\SubscriptionsTable;
use App\Models\Subscription;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;

class SubscriptionResource extends Resource
{
    protected static ?string $model = Subscription::class;

    protected static string|BackedEnum|null $navigationIcon = 'heroicon-o-bookmark-square';

    protected static string|\UnitEnum|null $navigationGroup = 'Payments & Plans';

    public static function canViewAny(): bool
    {
        return auth()->user() && in_array(auth()->user()->role, ['Super Admin', 'Moderator']);
    }

    public static function canCreate(): bool
    {
        return auth()->user() && auth()->user()->role === 'Super Admin';
    }

    public static function canEdit($record): bool
    {
        return auth()->user() && auth()->user()->role === 'Super Admin';
    }

    public static function canDelete($record): bool
    {
        return auth()->user() && auth()->user()->role === 'Super Admin';
    }

    public static function form(Schema $schema): Schema
    {
        return SubscriptionForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return SubscriptionsTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListSubscriptions::route('/'),
        ];
    }
}
